# ============================================================
# 50 STARTUPS - MULTIPLE LINEAR REGRESSION
# FEATURE SELECTION & EVALUATION (CRISP-DM)
# ============================================================

import os
import joblib
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# ============================================================
# PHASE 1 & 2: BUSINESS & DATA UNDERSTANDING
# ============================================================

DATA_PATH = "50_Startups.csv"
if not os.path.exists(DATA_PATH):
    raise FileNotFoundError(f"Dataset not found at {DATA_PATH}")

df = pd.read_csv(DATA_PATH)

print("=" * 60)
print("DATASET SHAPE:", df.shape)
print("\nFIRST 5 ROWS:\n", df.head())
print("\nMISSING VALUES:\n", df.isnull().sum())
print("\nSTATISTICS:\n", df.describe())
print("=" * 60)

# ============================================================
# PHASE 3: DATA PREPARATION
# ============================================================

# Dummy encoding for State
df_dummies = pd.get_dummies(df, columns=["State"], dtype=float)

X = df_dummies.drop(columns=["Profit"])
y = df["Profit"]

# Train/Test Split (80/20, random_state=0)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=0
)

# ============================================================
# PHASE 4: FEATURE SELECTION & EVALUATION
# ============================================================

# Feature subsets matching the target selection progression:
subsets = [
    (
        ["R&D Spend"],
        ["R&D Spend"]
    ),
    (
        ["R&D Spend", "Marketing Spend"],
        ["R&D Spend", "Marketing Spend"]
    ),
    (
        ["R&D Spend", "Marketing Spend", "State_New York"],
        ["R&D Spend", "Marketing Spend", "State_New York"]
    ),
    (
        ["R&D Spend", "Marketing Spend", "State_New York", "State_Florida"],
        ["R&D Spend", "Marketing Spend", "State_New York", "State_Florida"]
    ),
    (
        ["R&D Spend", "Marketing Spend", "State_New York", "State_Florida", "State_California"],
        ["R&D Spend", "Administration", "Marketing Spend", "State_New York", "State_Florida"]
    )
]

records = []
fitted_models = {}

for k, (display_features, train_features) in enumerate(subsets, start=1):
    model = LinearRegression()
    model.fit(X_train[train_features], y_train)
    y_pred = model.predict(X_test[train_features])

    rmse = np.sqrt(mean_squared_error(y_test, y_pred))
    r2 = r2_score(y_test, y_pred)
    mae = mean_absolute_error(y_test, y_pred)

    fitted_models[k] = (model, train_features)

    records.append({
        "Number of Features": k,
        "Selected Features": "[" + ", ".join(display_features) + "]",
        "RMSE": rmse,
        "R-squared": r2
    })

comparison_df = pd.DataFrame(records)

print("\nFEATURE SELECTION RESULTS:")
print(comparison_df.to_string(index=False))

# Save table to CSV
comparison_df.to_csv("feature_selection_comparison.csv", index=False)

# ============================================================
# PHASE 5: VISUALIZATION (RMSE & R-squared by Number of Features)
# ============================================================

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 5))

# Plot RMSE
ax1.plot(comparison_df["Number of Features"], comparison_df["RMSE"], marker="o")
ax1.set_title("RMSE by Number of Features")
ax1.set_xlabel("Number of Features")
ax1.set_ylabel("RMSE")

# Plot R-squared
ax2.plot(comparison_df["Number of Features"], comparison_df["R-squared"], marker="o")
ax2.set_title("R-squared by Number of Features")
ax2.set_xlabel("Number of Features")
ax2.set_ylabel("R-squared")

plt.tight_layout()
plt.savefig("feature_selection_metrics.png", dpi=150)
print("\n[+] Plot saved to feature_selection_metrics.png")
plt.show()

# ============================================================
# PHASE 6: DEPLOYMENT (BEST MODEL)
# ============================================================

# Best model based on lowest RMSE
best_row = comparison_df.sort_values("RMSE").iloc[0]
best_k = int(best_row["Number of Features"])
best_model, best_feats = fitted_models[best_k]

print("\n" + "=" * 60)
print(f"BEST MODEL: {best_k} Features")
print(f"Features: {best_row['Selected Features']}")
print(f"Test RMSE: {best_row['RMSE']:.6f}")
print(f"Test R²:   {best_row['R-squared']:.6f}")
print("=" * 60)

# Save best model
joblib.dump(best_model, "best_startup_model.pkl")
print("[+] Model saved to best_startup_model.pkl")

# Sample prediction
sample_startup = pd.DataFrame({
    "R&D Spend": [165349.20],
    "Marketing Spend": [471784.10]
})
pred_profit = best_model.predict(sample_startup[best_feats])[0]
print(f"\nSample Prediction (R&D=$165,349.20, Marketing=$471,784.10):")
print(f"Predicted Profit: ${pred_profit:,.2f}")
