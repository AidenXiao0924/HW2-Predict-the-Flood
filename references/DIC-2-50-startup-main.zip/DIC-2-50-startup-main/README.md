# 50 Startups 多元線性迴歸與特徵選擇決策套件 📊

> **CRISP-DM 資料科學專案 • 互動式機器學習決策儀表板**  
> 探索模型複雜度與泛化能力的權衡（Bias-Variance Tradeoff），驗證特徵簡約性原則（Parsimony）。

🌐 **線上互動式網站 (Live Demo)**：  
👉 **[https://aidenxiao0924.github.io/DIC-2-50-startup/](https://aidenxiao0924.github.io/DIC-2-50-startup/)**

---

## 📸 網站預覽截圖 (Dashboard Preview)

![50 Startups 特徵選擇與獲利決策儀表板](assets/dashboard_preview.png)

---

## 🌟 核心結論與實驗洞察

在 50 家新創公司數據集（50_Startups）的特徵選擇實驗中，我們驗證了**「變數越多不代表預測越準」**的核心數據科學原則：

| 特徵階數 $k$ | 選入特徵組合 (Selected Features) | 測試集 RMSE | 判定係數 $R^2$ | 模型評價 |
| :---: | :--- | :---: | :---: | :--- |
| **$k=1$** | `[R&D Spend]` | $8,274.87 | 0.9465 | 基準單變數模型，研發支出為最強預測因子 |
| **$k=2$ ★** | **`[R&D Spend, Marketing Spend]`** | **$8,198.80** | **0.9474** | **🏆 全局最佳甜蜜點（最低 RMSE、最高 $R^2$）** |
| **$k=3$** | `[R&D Spend, Marketing Spend, State_New York]` | $8,309.06 | 0.9460 | 納入州別後誤差開始微升 |
| **$k=4$** | `[R&D Spend, Marketing Spend, State_New York, State_Florida]` | $8,409.92 | 0.9447 | 邊際效益遞減，自由度懲罰增加 |
| **$k=5$ ⚠** | `[R&D Spend, Marketing Spend, State_New York, State_Florida, Administration]` | $9,137.99 | 0.9347 | ⚠ **過度擬合懸崖**（RMSE 大幅上升 +11.5%） |

### 💡 奧坎剃刀原則 (Occam's Razor)
加入**行政管理支出（Administration）**非但無法提升預測精準度，反而會引進不必要的雜訊與多重共線性，導致測試集泛化能力明顯劣化。**精準的 2 變數模型即可達成最佳商業決策效益。**

---

## 🚀 互動式網站核心功能

1. **五大特徵選擇演算法動態切換**：
   - **Lasso (L1 正規化)**：完全符合基準測試之重要性降序排名。
   - **前向逐步選擇 (Forward SFS)**：貪婪演算法逐步納入效益最大之特徵。
   - **遞迴特徵消除 (RFE)**：後向逐步剔除權重最小之因子。
   - **ElasticNet**：結合 L1 與 L2 正規化處理解釋變數共線性。
   - **窮舉法 (Exhaustive Best Subset)**：遍歷 $2^p$ 種特徵子集尋求數學最優解。
   - **全演算法綜合對比**：一鍵同時疊合五大演算法之學習曲線。

2. **雙指標特徵數量曲線圖 (Dual Interactive Charts)**：
   - **RMSE 隨特徵數變化曲線**：高光標註 $k=2$ 甜蜜點。
   - **$R^2$ 隨特徵數變化曲線**：展現 $k=5$ 時的過度擬合陡降現象。

3. **動態數學方程式渲染引擎**：
   - 根據當前選擇的模型，即時呈現多項式迴歸方程式：
     $$y = \text{Intercept} + \beta_1 X_1 + \beta_2 X_2 + \dots$$
   - 具備係數正負色彩識別與特徵膠囊標籤。

4. **What-If 即時獲利試算沙盒 (Profit Simulator)**：
   - 支援即時調整**研發預算**、**行銷預算**、**行政支出**與**所在州別**。
   - 結合當前模型權重即時運算預期淨利潤，並提供 **95% 預測信賴區間**與**瀑布流因素貢獻分解**。

5. **統計檢定矩陣與共線性診斷**：
   - 完整展示迴歸係數 ($\beta$)、標準誤、t-統計量、p-值顯著性星星標記（★★★）與 VIF 共線性指標。

---

## 📁 專案檔案架構

```text
├── index.html                         # 現代 Bento Grid 互動式儀表板前端
├── style.css                          # 暗黑/明亮雙主題與玻璃擬態 CSS 樣式庫
├── app.js                             # 互動運算核心與 Chart.js 動態渲染引擎
├── model_data.js                      # 五大演算法預先計算之回歸指標與統計數據庫
├── chart.min.js                       # Chart.js 本地備用離線套件
├── main.py                            # Python 訓練與評估管線（CRISP-DM 完整流程）
├── 50_Startups.csv                    # 原始數據集（研發、管理、行銷、州別、獲利）
├── feature_selection_comparison.csv   # 特徵評比量化指標對照表
├── feature_selection_metrics.png      # Matplotlib 基準測試曲線圖
├── assets/                            # 靜態資源目錄（包含展示截圖）
│   └── dashboard_preview.png
└── README.md                          # 專案中文完整說明文件
```

---

## 💻 本地端運行指南

### 1. 預覽互動式網站
直接以瀏覽器開啟 `index.html`，或啟動 Python 本地伺服器：

```bash
python -m http.server 8000
```
開啟瀏覽器前往 [http://localhost:8000](http://localhost:8000) 即可使用。

### 2. 執行 Python 機器學習訓練腳本
```bash
python main.py
```
腳本將依據 CRISP-DM 流程執行資料探索、前處理、特徵評比並輸出模型檔案 `best_startup_model.pkl`。
