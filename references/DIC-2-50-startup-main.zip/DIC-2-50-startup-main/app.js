/**
 * Quantum Startup Analytics - Interactive ML Engine
 * Multiple Linear Regression CRISP-DM Feature Selection Suite
 */

document.addEventListener('DOMContentLoaded', () => {
  // Validate model data
  if (!window.MODEL_DATA) {
    console.error('MODEL_DATA is missing.');
    return;
  }

  // Application State
  const state = {
    algo: 'Lasso',      // Default method matching benchmark
    k: 2,               // Default to global sweet spot (k=2)
    compareAll: false,  // Compare all 5 methods flag
    rmseChart: null,
    r2Chart: null,
    sliderValues: {
      rd: 165349.20,
      mkt: 471784.10,
      admin: 136897.80,
      state: 'New York'
    }
  };

  const ALGO_METADATA = {
    'Lasso': { color: '#06b6d4', glow: 'rgba(6, 182, 212, 0.4)', name: 'Lasso (L1 Ranking)', desc: 'Parsimonious feature ranking through L1 coefficient shrinkage.' },
    'Forward SFS': { color: '#6366f1', glow: 'rgba(99, 102, 241, 0.4)', name: 'Forward SFS', desc: 'Greedy sequential selection adding best RMSE reducing feature iteratively.' },
    'RFE': { color: '#10b981', glow: 'rgba(16, 185, 129, 0.4)', name: 'RFE (Backward)', desc: 'Recursive elimination pruning least influential predictor weights.' },
    'ElasticNet': { color: '#f59e0b', glow: 'rgba(245, 158, 11, 0.4)', name: 'ElasticNet', desc: 'Combined L1 & L2 penalties handling collinearity smoothly.' },
    'Exhaustive': { color: '#a855f7', glow: 'rgba(168, 85, 247, 0.4)', name: 'Exhaustive Search', desc: 'Evaluates all 2^p feature subsets to find mathematically optimal models.' }
  };

  // DOM Elements
  const algoPills = document.querySelectorAll('.algo-pill');
  const kStepCards = document.querySelectorAll('.k-step-card');
  const valRMSE = document.getElementById('valRMSE');
  const valR2 = document.getElementById('valR2');
  const valMAE = document.getElementById('valMAE');
  const valAdjR2 = document.getElementById('valAdjR2');
  const valFStat = document.getElementById('valFStat');
  const activeFeaturesContainer = document.getElementById('activeFeaturesContainer');
  const equationFormula = document.getElementById('equationFormula');
  const matrixTableBody = document.getElementById('matrixTableBody');
  const rawComparisonBody = document.getElementById('rawComparisonBody');
  
  // Simulator DOM
  const sliderRD = document.getElementById('sliderRD');
  const sliderMkt = document.getElementById('sliderMkt');
  const sliderAdmin = document.getElementById('sliderAdmin');
  const selectState = document.getElementById('selectState');
  const dispRD = document.getElementById('dispRD');
  const dispMkt = document.getElementById('dispMkt');
  const dispAdmin = document.getElementById('dispAdmin');
  const holoProfitNum = document.getElementById('holoProfitNum');
  const holoCIRange = document.getElementById('holoCIRange');
  const waterfallList = document.getElementById('waterfallList');
  const themeToggle = document.getElementById('themeToggle');

  // Formatters
  const fmtCurrency = (n) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(n);
  const fmtDec = (n, d = 4) => Number(n).toFixed(d);

  // Initialize
  initCharts();
  bindEvents();
  renderAll();

  // -------------------------------------------------------------
  // Event Binding
  // -------------------------------------------------------------
  function bindEvents() {
    // Algorithm Switcher
    algoPills.forEach(pill => {
      pill.addEventListener('click', () => {
        algoPills.forEach(p => p.classList.remove('active'));
        pill.classList.add('active');
        
        const targetAlgo = pill.dataset.algo;
        if (targetAlgo === 'ALL') {
          state.compareAll = true;
        } else {
          state.compareAll = false;
          state.algo = targetAlgo;
        }
        renderAll();
      });
    });

    // Feature Count Stepper
    kStepCards.forEach(card => {
      card.addEventListener('click', () => {
        kStepCards.forEach(c => c.classList.remove('active'));
        card.classList.add('active');
        state.k = parseInt(card.dataset.k, 10);
        renderAll();
      });
    });

    // Sliders
    const handleSliderInput = () => {
      state.sliderValues.rd = parseFloat(sliderRD.value);
      state.sliderValues.mkt = parseFloat(sliderMkt.value);
      state.sliderValues.admin = parseFloat(sliderAdmin.value);
      state.sliderValues.state = selectState.value;

      dispRD.textContent = fmtCurrency(state.sliderValues.rd);
      dispMkt.textContent = fmtCurrency(state.sliderValues.mkt);
      dispAdmin.textContent = fmtCurrency(state.sliderValues.admin);

      updateProfitPrediction();
    };

    sliderRD.addEventListener('input', handleSliderInput);
    sliderMkt.addEventListener('input', handleSliderInput);
    sliderAdmin.addEventListener('input', handleSliderInput);
    selectState.addEventListener('change', handleSliderInput);

    // Preset Chips
    document.querySelectorAll('.q-chip').forEach(chip => {
      chip.addEventListener('click', () => {
        const target = chip.dataset.target;
        const val = parseFloat(chip.dataset.val);
        if (target === 'rd') sliderRD.value = val;
        if (target === 'mkt') sliderMkt.value = val;
        if (target === 'admin') sliderAdmin.value = val;
        handleSliderInput();
      });
    });

    // Theme Toggle
    if (themeToggle) {
      themeToggle.addEventListener('click', () => {
        const cur = document.body.getAttribute('data-theme') || 'dark';
        const next = cur === 'dark' ? 'light' : 'dark';
        document.body.setAttribute('data-theme', next);
        themeToggle.innerHTML = next === 'light' ? '<i class="fa-solid fa-moon"></i>' : '<i class="fa-solid fa-sun"></i>';
        updateCharts();
      });
    }

    // Copy Git Commands
    document.querySelectorAll('.btn-mini-copy').forEach(btn => {
      btn.addEventListener('click', () => {
        const text = btn.dataset.copy;
        navigator.clipboard.writeText(text).then(() => {
          const old = btn.textContent;
          btn.textContent = 'Copied!';
          setTimeout(() => btn.textContent = old, 1500);
        });
      });
    });
  }

  // -------------------------------------------------------------
  // Data Retrieval
  // -------------------------------------------------------------
  function getCurrentModelData() {
    const list = window.MODEL_DATA[state.algo] || window.MODEL_DATA['Lasso'];
    return list.find(m => m.k === state.k) || list[0];
  }

  // -------------------------------------------------------------
  // Main Render Flow
  // -------------------------------------------------------------
  function renderAll() {
    updateKPIs();
    updateEquationAndFeatures();
    updateCoefficientsMatrix();
    updateRawComparisonTable();
    updateProfitPrediction();
    updateCharts();
  }

  // -------------------------------------------------------------
  // 1. KPIs
  // -------------------------------------------------------------
  function updateKPIs() {
    const model = getCurrentModelData();
    valRMSE.textContent = fmtCurrency(model.rmse);
    valR2.textContent = fmtDec(model.r2, 4);
    valMAE.textContent = fmtCurrency(model.mae);
    valAdjR2.textContent = fmtDec(model.adj_r2, 4);
    valFStat.textContent = model.f_stat ? Number(model.f_stat).toFixed(1) : 'N/A';

    // Highlight sweet spot indicator
    const sweetCard = document.getElementById('kpiRMSECard');
    if (sweetCard) {
      if (state.k === 2) {
        sweetCard.classList.add('featured');
      } else {
        sweetCard.classList.remove('featured');
      }
    }
  }

  // -------------------------------------------------------------
  // 2. Equation & Feature Chips
  // -------------------------------------------------------------
  function updateEquationAndFeatures() {
    const model = getCurrentModelData();

    // Feature chips
    activeFeaturesContainer.innerHTML = '';
    model.features.forEach(feat => {
      const tag = document.createElement('span');
      let typeClass = 'rd';
      if (feat.includes('Marketing')) typeClass = 'mkt';
      else if (feat.includes('State')) typeClass = 'state';
      else if (feat.includes('Admin')) typeClass = 'admin';

      tag.className = `feat-tag ${typeClass}`;
      tag.innerHTML = `<i class="fa-solid fa-check"></i> ${feat}`;
      activeFeaturesContainer.appendChild(tag);
    });

    // Mathematical formula string
    const interceptObj = model.coefficients.find(c => c.feature.includes('Intercept')) || { coef: 0 };
    let formulaHtml = `<span class="eq-num-primary">Profit</span> = <span class="eq-num-primary">${fmtCurrency(interceptObj.coef)}</span>`;

    model.coefficients.forEach(c => {
      if (c.feature.includes('Intercept')) return;
      const isPos = c.coef >= 0;
      const sign = isPos ? '+' : '-';
      const absVal = Math.abs(c.coef).toFixed(4);
      const colorClass = isPos ? 'eq-num-pos' : 'eq-num-neg';
      formulaHtml += ` ${sign} <span class="${colorClass}">${absVal}</span> × <span class="eq-var-name">[${c.feature}]</span>`;
    });

    equationFormula.innerHTML = formulaHtml;
  }

  // -------------------------------------------------------------
  // 3. Coefficients & Statistics Matrix
  // -------------------------------------------------------------
  function updateCoefficientsMatrix() {
    const model = getCurrentModelData();
    matrixTableBody.innerHTML = '';

    model.coefficients.forEach(row => {
      const tr = document.createElement('tr');
      const isIntercept = row.feature.includes('Intercept');
      const isPositive = row.coef >= 0;
      const coefFormatted = isIntercept ? fmtCurrency(row.coef) : fmtDec(row.coef, 4);

      // p-value formatting & stars
      let stars = '';
      if (row.pvalue < 0.001) stars = '★★★';
      else if (row.pvalue < 0.01) stars = '★★';
      else if (row.pvalue < 0.05) stars = '★';
      else stars = 'ns';

      // VIF badge
      let vifHtml = '<span style="color: var(--text-muted);">—</span>';
      if (row.vif !== null && row.vif !== undefined) {
        const vifVal = Number(row.vif).toFixed(2);
        const vifClass = row.vif < 5 ? 'vif-safe' : 'vif-warn';
        vifHtml = `<span class="vif-pill ${vifClass}">${vifVal}</span>`;
      }

      tr.innerHTML = `
        <td style="font-weight: 600;">
          <span style="color: ${isIntercept ? 'var(--cyan)' : 'var(--text-main)'};">
            ${row.feature}
          </span>
        </td>
        <td class="mono-num" style="color: ${isPositive ? '#34d399' : '#f87171'};">
          ${isPositive ? '+' : ''}${coefFormatted}
        </td>
        <td class="mono-num" style="color: var(--text-dim);">${fmtDec(row.stderr, 4)}</td>
        <td class="mono-num">${fmtDec(row.tstat, 2)}</td>
        <td>
          <span class="mono-num" style="color: ${row.pvalue < 0.05 ? '#34d399' : '#f59e0b'};">
            ${row.pvalue < 0.0001 ? '< 0.0001' : fmtDec(row.pvalue, 4)}
          </span>
          <span style="font-size: 0.72rem; color: #fbbf24; margin-left: 4px;">${stars}</span>
        </td>
        <td class="mono-num" style="font-size: 0.8rem; color: var(--text-muted);">
          [${fmtDec(row.ci_lower, 2)}, ${fmtDec(row.ci_upper, 2)}]
        </td>
        <td>${vifHtml}</td>
      `;
      matrixTableBody.appendChild(tr);
    });
  }

  // -------------------------------------------------------------
  // 4. Raw Comparison Table (All 5 Steps of Current Algo)
  // -------------------------------------------------------------
  function updateRawComparisonTable() {
    const list = window.MODEL_DATA[state.algo] || window.MODEL_DATA['Lasso'];
    rawComparisonBody.innerHTML = '';

    list.forEach(m => {
      const tr = document.createElement('tr');
      const isCurrent = m.k === state.k;
      const isOptimal = m.k === 2;

      if (isCurrent) tr.style.outline = '1px solid var(--cyan)';
      if (isOptimal) tr.classList.add('row-optimal');

      const featBadges = m.features.map(f => {
        let cls = 'rd';
        if (f.includes('Marketing')) cls = 'mkt';
        else if (f.includes('State')) cls = 'state';
        else if (f.includes('Admin')) cls = 'admin';
        return `<span class="feat-tag ${cls}" style="font-size: 0.7rem; padding: 1px 6px;">${f}</span>`;
      }).join(' ');

      tr.innerHTML = `
        <td style="font-weight: 700; text-align: center;">
          ${m.k} ${isOptimal ? '<span class="kpi-badge win">★ BEST</span>' : ''}
        </td>
        <td><div style="display: flex; flex-wrap: wrap; gap: 4px;">${featBadges}</div></td>
        <td class="mono-num" style="font-weight: 700; color: ${isOptimal ? '#34d399' : 'var(--text-main)'};">
          ${fmtCurrency(m.rmse)}
        </td>
        <td class="mono-num" style="font-weight: 700;">${fmtDec(m.r2, 6)}</td>
        <td class="mono-num" style="color: var(--text-dim);">${fmtCurrency(m.mae)}</td>
        <td>
          <button class="btn-mini-copy" data-pick="${m.k}">Inspect k=${m.k}</button>
        </td>
      `;
      rawComparisonBody.appendChild(tr);
    });

    // Hook click to select row
    rawComparisonBody.querySelectorAll('button[data-pick]').forEach(btn => {
      btn.addEventListener('click', () => {
        const k = parseInt(btn.dataset.pick, 10);
        state.k = k;
        kStepCards.forEach(c => {
          c.classList.toggle('active', parseInt(c.dataset.k, 10) === k);
        });
        renderAll();
      });
    });
  }

  // -------------------------------------------------------------
  // 5. Live Profit Simulator & Waterfall Attribution
  // -------------------------------------------------------------
  function updateProfitPrediction() {
    const model = getCurrentModelData();
    let profit = 0;
    const attribution = [];

    // Intercept
    const interceptObj = model.coefficients.find(c => c.feature.includes('Intercept')) || { coef: 0 };
    profit += interceptObj.coef;
    attribution.push({ name: 'Base Intercept (β₀)', delta: interceptObj.coef, type: 'base' });

    // Iterate features
    model.coefficients.forEach(c => {
      if (c.feature.includes('Intercept')) return;
      let val = 0;
      if (c.feature === 'R&D Spend') val = state.sliderValues.rd;
      else if (c.feature === 'Marketing Spend') val = state.sliderValues.mkt;
      else if (c.feature === 'Administration') val = state.sliderValues.admin;
      else if (c.feature === 'State_New York') val = state.sliderValues.state === 'New York' ? 1 : 0;
      else if (c.feature === 'State_Florida') val = state.sliderValues.state === 'Florida' ? 1 : 0;
      else if (c.feature === 'State_California') val = state.sliderValues.state === 'California' ? 1 : 0;

      const effect = c.coef * val;
      profit += effect;
      if (val > 0 || c.feature.includes('Spend') || c.feature.includes('Admin')) {
        attribution.push({
          name: `${c.feature} (${isFinite(val) && val > 1 ? fmtCurrency(val) : (val ? 'Active' : 'Inactive')})`,
          delta: effect,
          type: effect >= 0 ? 'pos' : 'neg'
        });
      }
    });

    // Render big number
    holoProfitNum.textContent = fmtCurrency(profit);

    // 95% Confidence Interval (~ ± 1.96 * RMSE / sqrt(n) approximation)
    const margin = 1.96 * (model.rmse / Math.sqrt(10));
    holoCIRange.innerHTML = `<i class="fa-solid fa-chart-area"></i> 95% Expected Range: <strong>${fmtCurrency(profit - margin)}</strong> — <strong>${fmtCurrency(profit + margin)}</strong>`;

    // Render Waterfall Attribution List
    waterfallList.innerHTML = '';
    attribution.forEach(item => {
      const row = document.createElement('div');
      row.className = 'attr-item';
      const isPositive = item.delta >= 0;
      row.innerHTML = `
        <span style="color: var(--text-dim);">${item.name}</span>
        <span class="attr-val" style="color: ${isPositive ? '#34d399' : '#f87171'};">
          ${isPositive ? '+' : ''}${fmtCurrency(item.delta)}
        </span>
      `;
      waterfallList.appendChild(row);
    });
  }

  // -------------------------------------------------------------
  // 6. Dual Chart.js Visualizations
  // -------------------------------------------------------------
  function initCharts() {
    const ctxRMSE = document.getElementById('chartRMSE').getContext('2d');
    const ctxR2 = document.getElementById('chartR2').getContext('2d');

    const commonOptions = {
      responsive: true,
      maintainAspectRatio: false,
      animation: { duration: 600, easing: 'easeOutQuart' },
      interaction: { mode: 'index', intersect: false },
      plugins: {
        legend: {
          display: false,
          labels: { color: '#94a3b8', font: { family: 'Inter', size: 12 } }
        },
        tooltip: {
          backgroundColor: 'rgba(15, 23, 42, 0.92)',
          titleFont: { family: 'Outfit', size: 13, weight: '700' },
          bodyFont: { family: 'Fira Code', size: 12 },
          padding: 12,
          borderColor: 'rgba(99, 102, 241, 0.3)',
          borderWidth: 1,
          cornerRadius: 8,
          callbacks: {
            label: function(context) {
              const val = context.parsed.y;
              return context.dataset.label + ': ' + (val > 100 ? fmtCurrency(val) : fmtDec(val, 6));
            }
          }
        }
      },
      scales: {
        x: {
          title: { display: true, text: 'Number of Features (k)', color: '#64748b', font: { family: 'Inter', size: 12, weight: '600' } },
          grid: { color: 'rgba(255, 255, 255, 0.05)' },
          ticks: { color: '#94a3b8', font: { family: 'Fira Code' } }
        },
        y: {
          grid: { color: 'rgba(255, 255, 255, 0.05)' },
          ticks: { color: '#94a3b8', font: { family: 'Fira Code' } }
        }
      }
    };

    // Chart 1: RMSE
    state.rmseChart = new Chart(ctxRMSE, {
      type: 'line',
      data: { labels: [1, 2, 3, 4, 5], datasets: [] },
      options: {
        ...commonOptions,
        scales: {
          ...commonOptions.scales,
          y: {
            ...commonOptions.scales.y,
            title: { display: true, text: 'Test RMSE ($)', color: '#64748b', font: { family: 'Inter', size: 12, weight: '600' } }
          }
        }
      }
    });

    // Chart 2: R-squared
    state.r2Chart = new Chart(ctxR2, {
      type: 'line',
      data: { labels: [1, 2, 3, 4, 5], datasets: [] },
      options: {
        ...commonOptions,
        scales: {
          ...commonOptions.scales,
          y: {
            ...commonOptions.scales.y,
            title: { display: true, text: 'Test R² Score', color: '#64748b', font: { family: 'Inter', size: 12, weight: '600' } }
          }
        }
      }
    });
  }

  function updateCharts() {
    if (!state.rmseChart || !state.r2Chart) return;

    const datasetsRMSE = [];
    const datasetsR2 = [];

    if (state.compareAll) {
      // Show all 5 methods
      Object.keys(window.MODEL_DATA).forEach(algoName => {
        const meta = ALGO_METADATA[algoName] || { color: '#94a3b8' };
        const dataList = window.MODEL_DATA[algoName];
        
        datasetsRMSE.push({
          label: algoName,
          data: dataList.map(m => m.rmse),
          borderColor: meta.color,
          backgroundColor: meta.color,
          borderWidth: algoName === state.algo ? 3 : 1.5,
          pointRadius: 4,
          pointHoverRadius: 7,
          tension: 0.25
        });

        datasetsR2.push({
          label: algoName,
          data: dataList.map(m => m.r2),
          borderColor: meta.color,
          backgroundColor: meta.color,
          borderWidth: algoName === state.algo ? 3 : 1.5,
          pointRadius: 4,
          pointHoverRadius: 7,
          tension: 0.25
        });
      });

      state.rmseChart.options.plugins.legend.display = true;
      state.r2Chart.options.plugins.legend.display = true;
    } else {
      // Single active algorithm with highlight point on current k
      const dataList = window.MODEL_DATA[state.algo] || window.MODEL_DATA['Lasso'];
      const meta = ALGO_METADATA[state.algo] || { color: '#06b6d4', glow: 'rgba(6, 182, 212, 0.2)' };

      // Point styling array
      const pointRadii = dataList.map(m => m.k === state.k ? 9 : 5);
      const pointColors = dataList.map(m => m.k === state.k ? '#ffffff' : meta.color);
      const pointBorderWidths = dataList.map(m => m.k === state.k ? 3 : 1);

      datasetsRMSE.push({
        label: `${state.algo} RMSE`,
        data: dataList.map(m => m.rmse),
        borderColor: meta.color,
        backgroundColor: meta.color,
        borderWidth: 2.8,
        pointRadius: pointRadii,
        pointHoverRadius: 10,
        pointBackgroundColor: pointColors,
        pointBorderColor: meta.color,
        pointBorderWidth: pointBorderWidths,
        tension: 0.2
      });

      datasetsR2.push({
        label: `${state.algo} R²`,
        data: dataList.map(m => m.r2),
        borderColor: '#a855f7',
        backgroundColor: '#a855f7',
        borderWidth: 2.8,
        pointRadius: pointRadii,
        pointHoverRadius: 10,
        pointBackgroundColor: pointColors,
        pointBorderColor: '#a855f7',
        pointBorderWidth: pointBorderWidths,
        tension: 0.2
      });

      state.rmseChart.options.plugins.legend.display = false;
      state.r2Chart.options.plugins.legend.display = false;
    }

    state.rmseChart.data.datasets = datasetsRMSE;
    state.rmseChart.update();

    state.r2Chart.data.datasets = datasetsR2;
    state.r2Chart.update();
  }
});
